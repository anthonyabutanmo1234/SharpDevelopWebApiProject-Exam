﻿using SharpDevelopWebApi.Models;
public class Patient: Person
{
	// public string Email  { get; set; }
	public int UserId { get; set; }
}